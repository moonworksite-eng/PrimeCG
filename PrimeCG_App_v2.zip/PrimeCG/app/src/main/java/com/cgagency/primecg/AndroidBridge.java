package com.cgagency.primecg;

import android.content.Intent;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Bridge between JavaScript (WebView/Puter.js) and Android native code.
 * Handles: settings navigation, custom rules, chat history, voice I/O.
 */
public class AndroidBridge {

    private final MainActivity activity;
    private final PrefManager prefManager;

    public AndroidBridge(MainActivity activity) {
        this.activity = activity;
        this.prefManager = new PrefManager(activity);
    }

    @JavascriptInterface
    public void openSettings() {
        activity.runOnUiThread(() -> {
            Intent intent = new Intent(activity, SettingsActivity.class);
            activity.startActivity(intent);
        });
    }

    @JavascriptInterface
    public String getCustomRules() {
        return prefManager.getCustomRules();
    }

    @JavascriptInterface
    public void startVoiceInput() {
        activity.runOnUiThread(activity::startVoiceRecognition);
    }

    @JavascriptInterface
    public void speak(String text) {
        activity.runOnUiThread(() -> activity.speakText(text));
    }

    @JavascriptInterface
    public void saveMessage(String sender, String text, String mode) {
        try {
            String existing = prefManager.getChatHistory();
            JSONArray arr = new JSONArray(existing);

            JSONObject msg = new JSONObject();
            msg.put("sender", sender);
            msg.put("text", text);
            msg.put("mode", mode);
            arr.put(msg);

            // Keep last 100 messages only
            if (arr.length() > 100) {
                JSONArray trimmed = new JSONArray();
                for (int i = arr.length() - 100; i < arr.length(); i++) {
                    trimmed.put(arr.get(i));
                }
                arr = trimmed;
            }

            prefManager.setChatHistory(arr.toString());
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public String getChatHistory() {
        return prefManager.getChatHistory();
    }

    @JavascriptInterface
    public void clearChatHistory() {
        prefManager.clearChatHistory();
    }

    @JavascriptInterface
    public void toggleBubble() {
        activity.runOnUiThread(activity::toggleBubbleService);
    }

    @JavascriptInterface
    public boolean isBubbleActive() {
        return activity.isBubbleRunning();
    }
}
