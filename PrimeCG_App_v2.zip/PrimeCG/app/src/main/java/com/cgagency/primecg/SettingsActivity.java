package com.cgagency.primecg;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private EditText etRules;
    private TextView btnSave, btnReset, tvSavedMsg;
    private PrefManager prefManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefManager = new PrefManager(this);

        etRules = findViewById(R.id.et_rules);
        btnSave = findViewById(R.id.btn_save);
        btnReset = findViewById(R.id.btn_reset);
        tvSavedMsg = findViewById(R.id.tv_saved_msg);

        // Load existing rules
        etRules.setText(prefManager.getCustomRules());

        btnSave.setOnClickListener(v -> saveRules());
        btnReset.setOnClickListener(v -> resetRules());
    }

    private void saveRules() {
        String rules = etRules.getText().toString().trim();
        prefManager.setCustomRules(rules);

        tvSavedMsg.setVisibility(View.VISIBLE);
        tvSavedMsg.postDelayed(() -> tvSavedMsg.setVisibility(View.GONE), 2000);

        Toast.makeText(this, "Rules saved!", Toast.LENGTH_SHORT).show();
    }

    private void resetRules() {
        prefManager.resetRulesToDefault();
        etRules.setText(PrefManager.DEFAULT_RULES);
        Toast.makeText(this, "Default rules restore ho gaye", Toast.LENGTH_SHORT).show();
    }
}
