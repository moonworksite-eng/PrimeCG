package com.cgagency.primecg;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {
    private static final String PREFS_NAME = "PrimeCGPrefs";
    private static final String KEY_RULES = "custom_rules";
    private static final String KEY_HISTORY = "chat_history";

    public static final String DEFAULT_RULES = "";

    private final SharedPreferences prefs;

    public PrefManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String getCustomRules() {
        return prefs.getString(KEY_RULES, DEFAULT_RULES);
    }

    public void setCustomRules(String rules) {
        prefs.edit().putString(KEY_RULES, rules).apply();
    }

    public void resetRulesToDefault() {
        prefs.edit().putString(KEY_RULES, DEFAULT_RULES).apply();
    }

    public String getChatHistory() {
        return prefs.getString(KEY_HISTORY, "[]");
    }

    public void setChatHistory(String json) {
        prefs.edit().putString(KEY_HISTORY, json).apply();
    }

    public void clearChatHistory() {
        prefs.edit().putString(KEY_HISTORY, "[]").apply();
    }
}
