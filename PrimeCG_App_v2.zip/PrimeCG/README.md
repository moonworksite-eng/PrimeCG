# ✦ Prime CG — Android App

Built by CG Chand — CG Agency
Free AI assistant powered by Puter.js (no API key needed)

---

## Features in this version

| Feature | Status |
|---|---|
| 🆓 Free AI access via Puter.js | ✅ |
| 🎤 Voice input (Hindi/Hinglish) | ✅ |
| 🔊 Voice output (TTS) | ✅ |
| 🔵 Floating Bubble (works over any app) | ✅ |
| 🟣 Chat History (auto-saved) | ✅ |
| 🟢 Copy button on AI messages | ✅ |
| ⚙ Custom Rules in Settings | ✅ |
| 🔁 Reset Rules to Default | ✅ |
| 🎯 5 Modes: General, Coding, Editing, Prompts, Sound FX | ✅ |
| 😐 Honest AI — no fake praise, direct feedback | ✅ |
| 🪪 Identity: "Built by CG Chand, CG Agency" | ✅ |
| 🌙 Dark cinematic UI | ✅ |

---

## Setup Steps

### Step 1 — Install Android Studio
Download: https://developer.android.com/studio

### Step 2 — Open Project
File → Open → select the `PrimeCG` folder

### Step 3 — Sign up on Puter (one time, free)
The app uses Puter.js which runs through `https://js.puter.com`.
First time the app runs, it may open a quick Puter login/signup popup inside the WebView — just sign up free (no card needed) and you're done permanently after that.

### Step 4 — Build & Run
1. Connect your Android phone via USB
2. Enable Developer Options + USB Debugging on your phone
3. Click Run (▶) in Android Studio
4. App installs on your phone!

---

## How the Floating Bubble works

1. Open Prime CG app
2. Tap the ◉ icon in the header
3. First time: Android will ask for **"Display over other apps"** permission → Allow it
4. Tap ◉ again → purple bubble appears on screen
5. Bubble works over ANY app — drag it anywhere, tap it to open Prime CG instantly
6. Tap ◉ again in app to turn bubble off

---

## How Custom Rules work

1. Tap ⚙ (Settings) in the app
2. Write your own rules in plain language, for example:
   ```
   - Code likhte waqt hamesha comments daalo
   - Reply chhota aur seedha rakho
   - Kabhi bhi flattery mat karo
   ```
3. Tap "Save Rules" — these rules now apply to EVERY AI response
4. Tap "Reset to Default" anytime to clear all custom rules

---

## Project Structure

```
PrimeCG/
├── app/src/main/
│   ├── assets/
│   │   └── index.html          ← Full chat UI + Puter.js AI logic (the "brain")
│   ├── java/com/cgagency/primecg/
│   │   ├── MainActivity.java       ← WebView host, voice, TTS
│   │   ├── AndroidBridge.java      ← JS ↔ Android communication
│   │   ├── BubbleService.java      ← Floating bubble overlay
│   │   ├── SettingsActivity.java   ← Custom rules screen
│   │   └── PrefManager.java        ← Saves rules & chat history
│   ├── res/
│   │   ├── layout/                 ← Settings + main screen XML
│   │   ├── drawable/               ← Button/bubble shapes
│   │   └── values/                 ← Colors, strings, theme
│   └── AndroidManifest.xml
├── build.gradle
└── README.md
```

---

## Important notes

- **No API key needed** — Puter.js handles AI access for free
- **Internet required** — AI responses need a connection
- **Chat history** is saved locally on your phone (last 100 messages)
- **AI personality**: Honest by design — it will disagree with you and point out flaws instead of just praising ideas

---

## Next version ideas (not in this build)
- Screen reading (Accessibility Service)
- Wake word ("Hey Prime CG")
- SFX Generator deep-link to download sources
